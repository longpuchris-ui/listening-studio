# 共同 Google Drive 上傳接收端

這是完整的 Apps Script 接收端程式。尚未部署，沒有預設 Google Drive 目的地，也沒有真實上傳驗證。

1. 在 Apps Script 建立獨立專案，加入 `Code.gs` 與 `Bridge.html`，並開啟資訊清單編輯以加入 `appsscript.json`。
2. 在「專案設定 → 指令碼屬性」設定 `ADMIN_EMAIL` 為管理者 Google 信箱。`ALLOWED_ORIGINS` 可使用預設的正式網站來源；如有變更網域，填寫明確的來源網址，逗號分隔。
3. 如標準 Google Cloud 專案要求，啟用 Google Drive API。部署網頁應用程式，**執行身分選「存取網頁應用程式的使用者」**；限制可存取的學校／Google 帳號範圍。每位老師首次使用需完成 Google 授權，並有共同資料夾編輯權限。不要改成未驗證的匿名 owner-write 上傳站。
4. 將 `/exec` 網址貼到網站「共同 Drive 設定」。管理者貼資料夾網址或 ID，按「設定共同資料夾」，在 Google 視窗完成操作。資料夾 ID 存於同一個 Apps Script 的指令碼屬性，所以所有使用這個接收端的人都會寫入同一個資料夾。
5. 連線網址可透過網站產生的已設定連線連結分發。若要讓網站本身預設使用共同接收端，將確認後的 `/exec` URL 寫入 `dist/cloud-config.json` 的 `endpoint` 再發佈；使用者便不用各自設定。
6. 匯出 WAV 後按「上傳共同 Google Drive」。可同時上傳 .listenbook 專案備份，以保留片段與設定，方便日後修改。

檔案以 512 KiB 分段經 google.script.run 上傳，接收端呼叫 Google Drive resumable upload。伺服器固定目的資料夾、驗證目前使用者、檔案型態與分段位置，不接受瀏覽器指定任意上傳網址。Google OAuth token 和 resumable session URL 只留在 Apps Script。

同一請求識別碼和 UserCache 避免已確認片段重送。網路失敗不自動重試寫入。接收端只在 Google 回傳檔案 ID 時宣告成功；部署後需實測登入、權限不足、上傳中斷、最終檔案可播放及專案備份可重新匯入。Apps Script 配額與學校 OAuth 管理政策仍適用。

目前檔案大小上限設定為 250 MB；不是 Google／LINE 的通用限制。正式驗收可依學校配額調整。
