/* Deploy as USER ACCESSING the web app. OAuth credentials never leave Apps Script.
 * v34 (2026-11): server-side name/extension/MIME/content checks, per-user hourly file limit, destination
 * folder re-checked per file, chunk offset resync for safe retries, final size verification, folder in receipts. */
var MAX_BYTES=250*1024*1024,CHUNK=524288,FILES_PER_HOUR=40;
var TYPES={'audio/wav':'.wav','application/json':'.listenbook'};
function doGet(e) {
  var props=PropertiesService.getScriptProperties();
  var allowed=(props.getProperty('ALLOWED_ORIGINS')||'https://longpuchris-ui.github.io').split(',').map(function(x){return x.trim()});
  var origin=String((e.parameter||{}).origin||'');
  var requestId=String((e.parameter||{}).request||'');
  if(allowed.indexOf(origin)<0||!(/^[a-zA-Z0-9-]{20,100}$/).test(requestId))return HtmlService.createHtmlOutput('此連線來源未獲允許。');
  var t=HtmlService.createTemplateFromFile('Bridge');t.origin=JSON.stringify(origin);t.requestId=JSON.stringify(requestId);
  return t.evaluate().setTitle('聽力錄音室 · 共同資料夾交件');
}
function userEmail_(){var email=Session.getActiveUser().getEmail();if(!email)throw Error('請以「存取網頁應用程式的使用者」執行，並完成 Google 授權。');return email.toLowerCase()}
function admin_(){var configured=(PropertiesService.getScriptProperties().getProperty('ADMIN_EMAIL')||'').toLowerCase();if(!configured||userEmail_()!==configured)throw Error('只有設定的管理者可以變更共同資料夾。')}
function headers_(){return {Authorization:'Bearer '+ScriptApp.getOAuthToken()}}
function parse_(r){var status=r.getResponseCode(),text=r.getContentText();if(status<200||status>=300)throw Error('Google Drive 回應 '+status+'，請確認資料夾權限及授權。');return text?JSON.parse(text):{}}
function folder_(id){if(!(/^[a-zA-Z0-9_-]{10,200}$/).test(id||''))throw Error('資料夾 ID 格式不正確。');var r=parse_(UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id)+'?fields=id,name,mimeType,trashed,capabilities(canAddChildren)&supportsAllDrives=true',{headers:headers_(),muteHttpExceptions:true}));if(r.mimeType!=='application/vnd.google-apps.folder')throw Error('指定的項目不是 Google Drive 資料夾。');if(r.trashed)throw Error('共同資料夾已在垃圾桶中，請管理者重新指定。');return {id:r.id,name:r.name,url:'https://drive.google.com/drive/folders/'+r.id,canUpload:!!(r.capabilities&&r.capabilities.canAddChildren)}}
function sharedDriveStatus(){var email=userEmail_(),p=PropertiesService.getScriptProperties(),id=p.getProperty('SHARED_FOLDER_ID');return {folder:id?folder_(id):null,canAdmin:email===(p.getProperty('ADMIN_EMAIL')||'').toLowerCase(),limits:{maxBytes:MAX_BYTES,filesPerHour:FILES_PER_HOUR}}}
function configureSharedFolder(id){admin_();var f=folder_(String(id));if(!f.canUpload)throw Error('管理者對此資料夾沒有上傳權限。');PropertiesService.getScriptProperties().setProperty('SHARED_FOLDER_ID',f.id);return {folder:f,canAdmin:true}}
function uploadKey_(id){if(!(/^[a-zA-Z0-9-]{20,100}$/).test(id||''))throw Error('上傳識別碼無效。');return 'upload:'+id}
// Only "<name>.wav" as audio/wav or "<name>.listenbook" as application/json; no path characters.
function cleanName_(name,mime){var ext=TYPES[mime];if(!ext)throw Error('只接受本站的 WAV 或 .listenbook 專案備份。');var n=String(name||'').replace(/[\x00-\x1F\x7F]/g,'').replace(/[\\\/:*?"<>|]/g,'_').trim().slice(0,180);if(!n||n.toLowerCase().slice(-ext.length)!==ext||n.length<=ext.length)throw Error('檔名需以 '+ext+' 結尾。');return n}
function rateLimit_(){var cache=CacheService.getUserCache(),key='rate:'+Math.floor(Date.now()/3600000),n=Number(cache.get(key)||0);if(n>=FILES_PER_HOUR)throw Error('一小時內交件檔案過多（上限 '+FILES_PER_HOUR+' 個），請稍後再試。');cache.put(key,String(n+1),3700)}
function beginSharedUpload(input){userEmail_();var key=uploadKey_(input.id),cache=CacheService.getUserCache(),prior=cache.get(key);if(prior){var p=JSON.parse(prior);return p.receipt||{offset:p.offset,folder:p.folder}}
  var total=Number(input.size),name=cleanName_(input.name,input.mime);
  if(!Number.isSafeInteger(total)||total<1||total>MAX_BYTES)throw Error('檔案大小需介於 1 byte 與 250 MB（此檔約 '+Math.round(total/1048576)+' MB）。');
  var status=sharedDriveStatus();if(!status.folder||!status.folder.canUpload)throw Error('尚未設定共同資料夾，或你沒有編輯權限。');
  if(input.expectedFolderId&&input.expectedFolderId!==status.folder.id)throw Error('共同資料夾已由管理者變更為「'+status.folder.name+'」，請回網站重新連接確認後再交件。');
  rateLimit_();
  var h=headers_();h['X-Upload-Content-Type']=input.mime;h['X-Upload-Content-Length']=String(total);
  var r=UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true&fields=id,name,webViewLink,size,parents',{method:'post',contentType:'application/json',headers:h,payload:JSON.stringify({name:name,mimeType:input.mime,parents:[status.folder.id],appProperties:{listeningStudio:'1',requestId:input.id}}),muteHttpExceptions:true});
  if(r.getResponseCode()!==200)throw Error('無法建立上傳作業（'+r.getResponseCode()+'），請檢查資料夾權限。');
  var all=r.getAllHeaders(),location=all.Location||all.location;if(!location||!/^https:\/\/www\.googleapis\.com\//.test(location))throw Error('Google Drive 未提供有效上傳作業。');
  var folder={id:status.folder.id,name:status.folder.name,url:status.folder.url};
  cache.put(key,JSON.stringify({url:location,total:total,offset:0,mime:input.mime,folder:folder}),21600);return {offset:0,folder:folder}}
function sniff_(mime,bytes){var s=String.fromCharCode.apply(null,bytes.slice(0,12).map(function(b){return b&255}));if(mime==='audio/wav'&&!(s.slice(0,4)==='RIFF'&&s.slice(8,12)==='WAVE'))throw Error('檔案內容不是 WAV 音檔，已拒收。');if(mime==='application/json'&&!/^\s*\{/.test(s))throw Error('專案備份內容格式不符，已拒收。')}
function uploadSharedPart(input){userEmail_();var key=uploadKey_(input.id),cache=CacheService.getUserCache(),lock=LockService.getUserLock();lock.waitLock(20000);try{
  var raw=cache.get(key);if(!raw)throw Error('上傳作業已過期（超過 6 小時），請重新交件。');var s=JSON.parse(raw);if(s.receipt)return s.receipt;
  var offset=Number(input.offset);
  // A retried call after a lost response: tell the page where Drive really is instead of failing.
  if(offset!==s.offset)return {done:false,offset:s.offset,resync:true};
  var bytes=Utilities.base64Decode(String(input.base64||''));
  if(bytes.length<1||bytes.length>CHUNK||offset+bytes.length>s.total||((offset+bytes.length<s.total)&&bytes.length%262144!==0))throw Error('上傳片段大小不正確。');
  if(offset===0)sniff_(s.mime,bytes);
  var h=headers_();h['Content-Range']='bytes '+offset+'-'+(offset+bytes.length-1)+'/'+s.total;
  var r=UrlFetchApp.fetch(s.url,{method:'put',contentType:s.mime,headers:h,payload:bytes,muteHttpExceptions:true,followRedirects:false});var code=r.getResponseCode();
  if(code===200||code===201){var f=JSON.parse(r.getContentText());if(!f.id)throw Error('缺少 Google Drive 檔案識別碼。');if(f.size&&Number(f.size)!==s.total)throw Error('Google Drive 回報的檔案大小與送出的不同，請到資料夾確認後重新交件。');
    s.receipt={done:true,fileId:f.id,name:f.name,size:s.total,url:f.webViewLink||'https://drive.google.com/file/d/'+f.id+'/view',folder:s.folder,offset:s.total};s.offset=s.total;cache.put(key,JSON.stringify(s),21600);return s.receipt}
  if(code===308){var rh=r.getAllHeaders(),range=String(rh.Range||rh.range||''),match=range.match(/bytes=0-(\d+)/);s.offset=match?Number(match[1])+1:0;cache.put(key,JSON.stringify(s),21600);return {done:false,offset:s.offset}}
  if(code>=500||code===429)throw Error('Google Drive 暫時忙碌（'+code+'），可重試。');
  throw Error('Google Drive 上傳中斷（'+code+'）。請到共同資料夾確認後重新交件。')}finally{lock.releaseLock()}}
